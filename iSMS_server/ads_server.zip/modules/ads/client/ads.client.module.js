(function (app) {
  'use strict';

  app.registerModule('ads');
})(ApplicationConfiguration);
