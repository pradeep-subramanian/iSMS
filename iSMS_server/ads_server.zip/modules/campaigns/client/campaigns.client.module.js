(function (app) {
  'use strict';

  app.registerModule('campaigns');
})(ApplicationConfiguration);
