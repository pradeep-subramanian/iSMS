'use strict';

/**
 * Module dependencies
 */
var path = require('path'),
  config = require(path.resolve('./config/config'));

/**
 * Campaigns module init function.
 */
module.exports = function (app, db) {

};
