(function (app) {
  'use strict';

  app.registerModule('producers');
})(ApplicationConfiguration);
